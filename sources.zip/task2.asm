global average_rating ; make _start visible to the linker

section .data ; initialised data lives here
total dq 0

section .text ; instructions live here

	
;rdi Book* books, rsi long n
average_rating:
	xor rax, rax
	xor rcx, rcx
	pxor xmm0, xmm0
.loop:
	cmp rcx, rsi
	jge .done



	imul r8, rcx, 24
	add r8, 8
	movsd xmm1, [rdi + r8]
	addsd xmm0, xmm1
	inc rcx
	jmp .loop
	

.done:
	cvtsi2sd xmm1, rsi
	divsd xmm0, xmm1
	ret


